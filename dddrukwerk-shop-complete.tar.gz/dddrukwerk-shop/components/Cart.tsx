'use client'

import { useState } from 'react'
import styles from './Cart.module.css'

interface CartItem {
  id: string
  name: string
  basePrice: number
  quantity: number
  customization: Record<string, string>
  totalPrice: string
}

interface CartProps {
  items: CartItem[]
  onRemove: (index: number) => void
  onClose: () => void
}

export default function Cart({ items, onRemove, onClose }: CartProps) {
  const [checkoutStep, setCheckoutStep] = useState<'review' | 'checkout'>('review')
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zipcode: '',
  })

  const totalPrice = items.reduce((sum, item) => sum + parseFloat(item.totalPrice), 0)

  const handleCheckout = async () => {
    if (!customerInfo.name || !customerInfo.email || !customerInfo.address) {
      alert('Vul alle verplichte velden in')
      return
    }

    // In production, this would call your backend to create a Mollie payment
    console.log('Checkout data:', {
      items,
      customer: customerInfo,
      total: totalPrice
    })

    alert('Bestellingsproces gestart! In production integreert dit met Mollie.')
  }

  return (
    <div className={styles.cartOverlay}>
      <div className={styles.cartPanel}>
        <button className={styles.closeBtn} onClick={onClose}>✕</button>

        <h2>Winkelwagen</h2>

        {items.length === 0 ? (
          <p className={styles.empty}>Je winkelwagen is leeg</p>
        ) : (
          <>
            <div className={styles.items}>
              {items.map((item, idx) => (
                <div key={idx} className={styles.item}>
                  <div className={styles.itemInfo}>
                    <h4>{item.name}</h4>
                    <p className={styles.customization}>
                      {Object.values(item.customization).filter(v => v).join(' • ')}
                    </p>
                    <p className={styles.qty}>Hoeveelheid: {item.quantity}</p>
                  </div>
                  <div className={styles.itemPrice}>
                    <strong>€{item.totalPrice}</strong>
                    <button 
                      className={styles.removeBtn}
                      onClick={() => onRemove(idx)}
                    >
                      Verwijderen
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className={styles.summary}>
              <div className={styles.summaryRow}>
                <span>Subtotaal:</span>
                <span>€{totalPrice.toFixed(2)}</span>
              </div>
              <div className={styles.summaryRow}>
                <span>Verzending:</span>
                <span>€3.50</span>
              </div>
              <div className={styles.summaryTotal}>
                <span>Totaal:</span>
                <strong>€{(totalPrice + 3.50).toFixed(2)}</strong>
              </div>
            </div>

            {checkoutStep === 'review' ? (
              <button 
                className={styles.checkoutBtn}
                onClick={() => setCheckoutStep('checkout')}
              >
                Doorgaan naar Betaling
              </button>
            ) : (
              <div className={styles.checkoutForm}>
                <h3>Bestelgegevens</h3>
                
                <div className={styles.formGroup}>
                  <label>Naam *</label>
                  <input
                    type="text"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})}
                    placeholder="Volledige naam"
                  />
                </div>

                <div className={styles.formGroup}>
                  <label>Email *</label>
                  <input
                    type="email"
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo({...customerInfo, email: e.target.value})}
                    placeholder="je@voorbeeld.nl"
                  />
                </div>

                <div className={styles.formGroup}>
                  <label>Telefoonnummer</label>
                  <input
                    type="tel"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({...customerInfo, phone: e.target.value})}
                    placeholder="06 12345678"
                  />
                </div>

                <div className={styles.formGroup}>
                  <label>Adres *</label>
                  <input
                    type="text"
                    value={customerInfo.address}
                    onChange={(e) => setCustomerInfo({...customerInfo, address: e.target.value})}
                    placeholder="Straat en huisnummer"
                  />
                </div>

                <div className={styles.formRow}>
                  <div className={styles.formGroup}>
                    <label>Postcode</label>
                    <input
                      type="text"
                      value={customerInfo.zipcode}
                      onChange={(e) => setCustomerInfo({...customerInfo, zipcode: e.target.value})}
                      placeholder="1234 AB"
                    />
                  </div>
                  <div className={styles.formGroup}>
                    <label>Plaats</label>
                    <input
                      type="text"
                      value={customerInfo.city}
                      onChange={(e) => setCustomerInfo({...customerInfo, city: e.target.value})}
                      placeholder="Amsterdam"
                    />
                  </div>
                </div>

                <button 
                  className={styles.payBtn}
                  onClick={handleCheckout}
                >
                  Betaal met iDEAL (Mollie)
                </button>

                <button 
                  className={styles.backBtn}
                  onClick={() => setCheckoutStep('review')}
                >
                  Terug naar winkelwagen
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
