'use client'

import { useState } from 'react'
import Header from '@/components/Header'
import Hero from '@/components/Hero'
import ProductShowcase from '@/components/ProductShowcase'
import Cart from '@/components/Cart'
import Footer from '@/components/Footer'

export default function Home() {
  const [cartOpen, setCartOpen] = useState(false)
  const [cart, setCart] = useState<any[]>([])

  const addToCart = (product: any) => {
    setCart([...cart, product])
  }

  const removeFromCart = (index: number) => {
    setCart(cart.filter((_, i) => i !== index))
  }

  return (
    <>
      <Header 
        cartCount={cart.length} 
        onCartClick={() => setCartOpen(!cartOpen)} 
      />
      
      <main>
        <Hero />
        <ProductShowcase onAddToCart={addToCart} />
      </main>

      {cartOpen && (
        <Cart 
          items={cart} 
          onRemove={removeFromCart}
          onClose={() => setCartOpen(false)}
        />
      )}

      <Footer />
    </>
  )
}
